// import React, { useEffect, useState } from 'react';
// import { useKeycloak } from '@react-keycloak/web';

// function Home() {
//   // ดึง keycloak instance และ flag ที่บอกว่า initialize แล้ว
//   const { keycloak, initialized } = useKeycloak();
//   // สร้าง state เพื่อเก็บข้อมูล API ซึ่งเป็นอ็อบเจ็กต์
//   const [apiData, setApiData] = useState(null);

//   // useEffect สำหรับการเช็คการ authenticate
//   useEffect(() => {
//     if (initialized && !keycloak.authenticated) {
//       keycloak.login();
//     }
//   }, [initialized, keycloak]);

//   // ฟังก์ชันสำหรับดึงข้อมูลจาก API
//   const fetchData = async () => {
//     const response = await fetch('http://localhost:8081/api/data', {
//       headers: {
//         Authorization: `Bearer ${keycloak.token}`,
//       },
//     });
//     const result = await response.json();
//     // เก็บข้อมูลทั้งหมดที่ได้รับจาก API ใน state
//     setApiData(result);
//   };

//   // ถ้ายังไม่ initialize ให้แสดง Loading...
//   if (!initialized) {
//     return <div>Loading...</div>;
//   }

//   return (
//     <div style={{ padding: '20px' }}>
//       {keycloak.authenticated ? (
//         <>
//           <h1>
//             ยินดีต้อนรับ, {keycloak.tokenParsed?.preferred_username}
//           </h1>
//           <button onClick={fetchData}>เรียกข้อมูลจาก API</button>

//           {/* ถ้ามีข้อมูลจาก API ให้แสดง key-value ทั้งหมด */}
//           {apiData && (
//             <div>
//               <h2>ข้อมูลจาก API:</h2>
//               {Object.entries(apiData).map(([key, value]) => (
//                 <p key={key}>
//                   <strong>{key}:</strong> {JSON.stringify(value)}
//                 </p>
//               ))}
//             </div>
//           )}

//           <button onClick={() => keycloak.logout()}>ออกจากระบบ</button>
//         </>
//       ) : (
//         <div>กำลังไปหน้า Login...</div>
//       )}
//     </div>
//   );
// }

// export default Home;


// import React, { useEffect, useState } from 'react';
// import { useKeycloak } from '@react-keycloak/web';

// function Home() {
//   const { keycloak, initialized } = useKeycloak();
//   const [apiData, setApiData] = useState(null);
//   const [tokenClaims, setTokenClaims] = useState(null);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     if (initialized && !keycloak.authenticated) {
//       keycloak.login();
//     }
//   }, [initialized, keycloak]);

//   const fetchTokenClaims = async () => {
//     try {
//       // ตรวจสอบว่า token มีค่าอยู่จริง ๆ
//       if (!keycloak.token) {
//         setError('ไม่มี Token');
//         return;
//       }

//       const response = await fetch('http://localhost:8081/api/token', {
//         method: 'GET',
//         headers: {
//           Authorization: `Bearer ${keycloak.token}`,
//         },
//       });

//       if (!response.ok) {
//         throw new Error('ไม่สามารถดึง JWT Claims ได้');
//       }

//       const result = await response.json();
//       // ตรวจสอบว่า token_claims มีข้อมูลหรือไม่
//       if (result.token) {
//         setTokenClaims({ raw: result.token });
//       } else {
//         setError('ไม่พบ Claims');
//       }
//     } catch (err) {
//       console.error('Error fetching token claims:', err);
//       setError('ไม่สามารถดึง JWT Claims ได้');
//     }
//   };

//   const fetchData = async () => {
//     try {

//       await keycloak.updateToken(5);

//       const response = await fetch('http://localhost:8081/api/data', {
//         headers: {
//           Authorization: `Bearer ${keycloak.token}`,
//         },
//       });

//       if (!response.ok) {
//         throw new Error('API request failed');
//       }

//       const result = await response.json();
//       setApiData(result);
//       setError(null);
//     } catch (err) {
//       console.error('Fetch error:', err);
//       setError('ไม่สามารถเรียกข้อมูลได้');
//     }
//   };

//   if (!initialized) {
//     return <div>Loading...</div>;
//   }

//   return (
//     <div style={{ padding: '30px', fontFamily: 'sans-serif' }}>
//       {keycloak.authenticated ? (
//         <>
//           <h1>👋 สวัสดี, {keycloak.tokenParsed?.preferred_username}</h1>

//           <div style={{ margin: '20px 0' }}>
//             <h3>🔐 Token ของคุณ:</h3>
//             <textarea
//               readOnly
//               rows={6}
//               style={{ width: '100%', padding: '10px' }}
//               value={keycloak.token || 'ไม่มี Token'}
//             />
//           </div>

//           <button onClick={fetchTokenClaims}>แสดง JWT Claims</button>
//           {tokenClaims && (
//             <div>
//               <h2>JWT Claims:</h2>
//               {Object.entries(tokenClaims).map(([key, value]) => (
//                 <p key={key}>
//                   <strong>{key}:</strong> {JSON.stringify(value)}
//                 </p>
//               ))}
//             </div>
//           )}

//           <button onClick={fetchData}>📡 เรียกข้อมูลจาก API</button>

//           {error && <p style={{ color: 'red' }}>{error}</p>}

//           {apiData && (
//             <div style={{ marginTop: '20px' }}>
//               <h2>📦 ข้อมูลจาก API:</h2>
//               {Object.entries(apiData).map(([key, value]) => (
//                 <p key={key}>
//                   <strong>{key}:</strong> {JSON.stringify(value)}
//                 </p>
//               ))}
//             </div>
//           )}

//           <div style={{ marginTop: '30px' }}>
//             <button onClick={() => keycloak.logout()}>🚪 ออกจากระบบ</button>
//           </div>
//         </>
//       ) : (
//         <div>กำลังเปลี่ยนเส้นทางไปหน้า Login...</div>
//       )}
//     </div>
//   );
// }

// export default Home;

import React, { useEffect, useState } from 'react';
import { useKeycloak } from '@react-keycloak/web';
import TokenDisplay from './Tokendisplay'; // นำเข้าคอมโพเนนต์ที่สร้างใหม่

function Home() {
  const { keycloak, initialized } = useKeycloak();
  const [apiData, setApiData] = useState(null);
  const [tokenClaims, setTokenClaims] = useState(null);
  const [error, setError] = useState(null);
  const [showClaims, setShowClaims] = useState(false);
  const [showApiData, setShowApiData] = useState(false);

  useEffect(() => {
    if (initialized && !keycloak.authenticated) {
      keycloak.login();
    }
  }, [initialized, keycloak]);

  const toggleTokenClaims = async () => {
    try {
      // ถ้าไม่แสดง claims อยู่แล้ว และไม่มีข้อมูล claims ให้ดึงข้อมูลก่อน
      if (!showClaims && !tokenClaims) {
        if (!keycloak.tokenParsed) {
          setError('ไม่มีข้อมูล Token');
          return;
        }
        
        setTokenClaims(keycloak.tokenParsed);
        setError(null);
      }
      
      // สลับสถานะการแสดงผล
      setShowClaims(!showClaims);
    } catch (err) {
      console.error('Error getting token claims:', err);
      setError('ไม่สามารถดึง JWT Claims ได้');
    }
  };

  const fetchData = async () => {
    try {
      await keycloak.updateToken(5);

      const response = await fetch('http://localhost:8081/api/data', {
        headers: {
          Authorization: `Bearer ${keycloak.token}`,
        },
      });

      if (!response.ok) {
        throw new Error('API request failed');
      }

      const result = await response.json();
      setApiData(result);
      setShowApiData(true);
      setError(null);
    } catch (err) {
      console.error('Fetch error:', err);
      setError('ไม่สามารถเรียกข้อมูลได้');
    }
  };

  const toggleApiData = async () => {
    if (!apiData) {
      // ถ้ายังไม่มีข้อมูล API ให้เรียกข้อมูลก่อน
      await fetchData();
    } else {
      // ถ้ามีข้อมูลแล้ว แค่สลับสถานะการแสดงผล
      setShowApiData(!showApiData);
    }
  };

  if (!initialized) {
    return <div>Loading...</div>;
  }

  return (
    <div style={{ padding: '30px', fontFamily: 'sans-serif', maxWidth: '1000px', margin: '0 auto' }}>
      {keycloak.authenticated ? (
        <>
          <h1 style={{ borderBottom: '2px solid #3498db', paddingBottom: '10px' }}>
            👋 สวัสดี, {keycloak.tokenParsed?.preferred_username}
          </h1>

          {/* ใช้คอมโพเนนต์ TokenDisplay ที่ปรับปรุงแล้ว */}
          <TokenDisplay token={keycloak.token} />

          <div style={{ marginTop: '20px', display: 'flex', gap: '10px' }}>
            <button 
              onClick={toggleTokenClaims}
              style={{
                padding: '10px 15px',
                backgroundColor: showClaims ? '#e67e22' : '#3498db',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              {showClaims ? 'ซ่อน JWT Claims' : 'แสดง JWT Claims'}
            </button>
            
            <button 
              onClick={toggleApiData}
              style={{
                padding: '10px 15px',
                backgroundColor: showApiData ? '#e67e22' : '#2ecc71',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              {showApiData ? 'ซ่อนข้อมูล API' : '📡 เรียกข้อมูลจาก API'}
            </button>
          </div>

          {error && (
            <p style={{ 
              color: 'white', 
              backgroundColor: '#e74c3c', 
              padding: '10px', 
              borderRadius: '4px',
              marginTop: '15px'
            }}>
              ❌ {error}
            </p>
          )}

          {showClaims && tokenClaims && (
            <div style={{ 
              marginTop: '20px', 
              backgroundColor: '#f8f8f8',
              border: '1px solid #ddd',
              borderRadius: '4px',
              padding: '15px'
            }}>
              <h2 style={{ borderBottom: '1px solid #ddd', paddingBottom: '10px' }}>
                JWT Claims:
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', rowGap: '10px' }}>
                {Object.entries(tokenClaims).map(([key, value]) => (
                  <React.Fragment key={key}>
                    <div style={{ fontWeight: 'bold', color: '#333' }}>{key}:</div>
                    <div style={{ overflowWrap: 'break-word' }}>
                      {typeof value === 'object' 
                        ? JSON.stringify(value, null, 2) 
                        : String(value)}
                    </div>
                  </React.Fragment>
                ))}
              </div>
            </div>
          )}

          {showApiData && apiData && (
            <div style={{ 
              marginTop: '20px',
              backgroundColor: '#f8f8f8',
              border: '1px solid #ddd',
              borderRadius: '4px',
              padding: '15px'
            }}>
              <h2 style={{ borderBottom: '1px solid #ddd', paddingBottom: '10px' }}>
                📦 ข้อมูลจาก API:
              </h2>
              <div style={{ display: 'grid', gridTemplateColumns: '200px 1fr', rowGap: '10px' }}>
                {Object.entries(apiData).map(([key, value]) => (
                  <React.Fragment key={key}>
                    <div style={{ fontWeight: 'bold', color: '#333' }}>{key}:</div>
                    <div style={{ overflowWrap: 'break-word' }}>
                      {typeof value === 'object' 
                        ? JSON.stringify(value, null, 2) 
                        : String(value)}
                    </div>
                  </React.Fragment>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginTop: '30px' }}>
            <button 
              onClick={() => keycloak.logout()}
              style={{
                padding: '10px 15px',
                backgroundColor: '#e74c3c',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              🚪 ออกจากระบบ
            </button>
          </div>
        </>
      ) : (
        <div style={{ 
          padding: '20px', 
          backgroundColor: '#f8f8f8', 
          borderRadius: '4px',
          textAlign: 'center'
        }}>
          กำลังเปลี่ยนเส้นทางไปหน้า Login...
        </div>
      )}
    </div>
  );
}

export default Home;