import React, { useState } from 'react';

// คอมโพเนนต์สำหรับแสดง JWT Token แบบสวยงาม แต่ไม่มีการถอดรหัส
const TokenDisplay = ({ token }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showTokenParts, setShowTokenParts] = useState(false);
  
  if (!token) return <div>ไม่มี Token</div>;
  
  // แยกส่วนของ JWT token (header, payload, signature) เพื่อแสดงผลที่สวยงาม
  const tokenParts = token.split('.');
  
  return (
    <div style={{ margin: '20px 0', width: '100%' }}>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '10px' 
      }}>
        <h3 style={{ margin: 0 }}>🔐 Token ของคุณ:</h3>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={() => setIsExpanded(!isExpanded)}
            style={{
              background: '#f0f0f0',
              border: '1px solid #ddd',
              borderRadius: '4px',
              padding: '5px 10px',
              cursor: 'pointer'
            }}
          >
            {isExpanded ? 'ย่อ Token' : 'ขยาย Token'}
          </button>
          <button 
            onClick={() => setShowTokenParts(!showTokenParts)}
            style={{
              background: showTokenParts ? '#e67e22' : '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              padding: '5px 10px',
              cursor: 'pointer'
            }}
          >
            {showTokenParts ? 'ซ่อนรายละเอียด Token' : 'แสดงรายละเอียด Token'}
          </button>
        </div>
      </div>
      
      {isExpanded ? (
        <div style={{ fontFamily: 'monospace' }}>
          {/* แสดง token เต็มรูปแบบ */}
          <textarea
            readOnly
            rows={6}
            style={{ 
              width: '100%', 
              padding: '10px',
              fontFamily: 'monospace',
              backgroundColor: '#f8f8f8',
              border: '1px solid #ddd',
              borderRadius: '4px'
            }}
            value={token}
          />
        </div>
      ) : (
        <div style={{ 
          fontFamily: 'monospace',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis',
          padding: '10px',
          backgroundColor: '#f8f8f8',
          border: '1px solid #ddd',
          borderRadius: '4px'
        }}>
          {token.substring(0, 20)}...{token.substring(token.length - 10)}
        </div>
      )}
      
      {/* แสดงส่วนประกอบของ JWT แยกเป็นส่วนๆ แต่ไม่ถอดรหัส */}
      {showTokenParts && (
        <div style={{ marginTop: '15px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {/* Header part */}
            <div style={{ 
              backgroundColor: '#fdedec', 
              border: '1px solid #e74c3c',
              borderRadius: '4px',
              padding: '10px',
              position: 'relative'
            }}>
              <span style={{ 
                position: 'absolute',
                top: '-10px',
                left: '10px',
                backgroundColor: '#e74c3c',
                color: 'white',
                padding: '2px 8px',
                borderRadius: '4px',
                fontSize: '12px'
              }}>
                HEADER
              </span>
              <div style={{ 
                fontFamily: 'monospace', 
                wordBreak: 'break-all',
                marginTop: '5px'
              }}>
                {tokenParts[0] || 'ไม่มีข้อมูล'}
              </div>
            </div>
            
            {/* Payload part */}
            <div style={{ 
              backgroundColor: '#eafaf1', 
              border: '1px solid #2ecc71',
              borderRadius: '4px',
              padding: '10px',
              position: 'relative'
            }}>
              <span style={{ 
                position: 'absolute',
                top: '-10px',
                left: '10px',
                backgroundColor: '#2ecc71',
                color: 'white',
                padding: '2px 8px',
                borderRadius: '4px',
                fontSize: '12px'
              }}>
                PAYLOAD
              </span>
              <div style={{ 
                fontFamily: 'monospace', 
                wordBreak: 'break-all',
                marginTop: '5px'
              }}>
                {tokenParts[1] || 'ไม่มีข้อมูล'}
              </div>
            </div>
            
            {/* Signature part */}
            <div style={{ 
              backgroundColor: '#ebf5fb', 
              border: '1px solid #3498db',
              borderRadius: '4px',
              padding: '10px',
              position: 'relative'
            }}>
              <span style={{ 
                position: 'absolute',
                top: '-10px',
                left: '10px',
                backgroundColor: '#3498db',
                color: 'white',
                padding: '2px 8px',
                borderRadius: '4px',
                fontSize: '12px'
              }}>
                SIGNATURE
              </span>
              <div style={{ 
                fontFamily: 'monospace', 
                wordBreak: 'break-all',
                marginTop: '5px'
              }}>
                {tokenParts[2] || 'ไม่มีข้อมูล'}
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* ปุ่มคัดลอก Token */}
      <button 
        onClick={() => {
          navigator.clipboard.writeText(token);
          alert('คัดลอก Token แล้ว');
        }}
        style={{
          marginTop: '15px',
          background: '#3498db',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          padding: '8px 15px',
          cursor: 'pointer',
          fontSize: '14px'
        }}
      >
        📋 คัดลอก Token
      </button>
    </div>
  );
};

export default TokenDisplay;